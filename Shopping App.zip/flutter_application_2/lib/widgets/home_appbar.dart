import 'package:flutter/material.dart';

class HomeAppbar extends StatelessWidget {
  const HomeAppbar({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
            children: [
              Text(
                "Shopping\nApp",
                style: Theme.of(context).textTheme.titleLarge,
              ),
              Expanded(
                child: TextField(
                  decoration: InputDecoration(
                    hintText: "Search....",
                    prefixIcon: Icon(Icons.search),
                  ),
                ),
              ),
            ],
          );
  }
}
