import 'package:flutter/material.dart';

class BrandsFilter extends StatelessWidget {
  const BrandsFilter({super.key});

  @override
  Widget build(BuildContext context) {
    List<String> brands = [
      "All",
      "Nike",
      "Puma",
      "Addidas",
      "Ndure",
      "Sketchers",
      "Reebok",
      "CR7",
    ];
    return SizedBox(
      height: 100,

      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: brands.length,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Chip(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadiusGeometry.circular(20),
              ),
              side: BorderSide(color: Color.fromRGBO(245, 247, 249, 1)),
              backgroundColor: Color.fromRGBO(245, 247, 249, 1),
              padding: EdgeInsets.all(10),
              label: Text(brands[index]),
            ),
          );
        },
      ),
    );
  }
}
