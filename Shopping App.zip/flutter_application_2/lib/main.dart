import 'package:flutter/material.dart';
import 'package:flutter_application_2/screens/product_details.dart';

void main() {
  runApp(const ShoppingApp());
}

class ShoppingApp extends StatelessWidget {
  const ShoppingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // theme: ThemeData.dark(),
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: "Lato",
        textTheme: TextTheme(
          titleLarge: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),

          titleMedium: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),

          bodyMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
      // home: HomeScreen()
      // home: CartScreen(),
      home: ProductDetails(),
    );
  }
}
